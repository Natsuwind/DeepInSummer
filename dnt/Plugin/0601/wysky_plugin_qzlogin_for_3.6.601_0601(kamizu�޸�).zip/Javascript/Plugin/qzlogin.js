﻿function toQzoneLogin(urlparam) {
    var A = window.open("QZoneLogin.aspx?" + urlparam, "TencentLogin", "width=500,height=400,menubar=0,scrollbars=1, resizable=1,status=1,titlebar=0,toolbar=0,location=1");
}